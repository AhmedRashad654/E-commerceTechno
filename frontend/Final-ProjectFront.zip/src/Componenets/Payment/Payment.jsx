import React from 'react'

export default function Payment() {
  return (
    <div>
      Payment
    </div>
  )
}

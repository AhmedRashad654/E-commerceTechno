import React from 'react'

export default function StaticSideDetails() {
  return (
    <div>StaticSideDetails</div>
  )
}
